import { Role, Permissions } from "../types";

// Berechtigungen für jede Rolle
export const ROLE_PERMISSIONS: Record<Role, Permissions> = {
  Admin: {
    canNavigateBack: true, // Kann zurück navigieren
    canEditProfile: true, // Kann Profil bearbeiten
    canEditTaxYears: true, // Kann Steuerjahre bearbeiten
    canDeleteTaxYears: true, // Kann Steuerjahre löschen
    canAddClient: true, // Kann Kunden hinzufügen
    canEditClient: true, // Kann Kunden bearbeiten
    canDeleteClient: true, // Kann Kunden löschen
  },
  Advisor: {
    canNavigateBack: true,
    canEditProfile: true,
    canEditTaxYears: true,
    canDeleteTaxYears: false, // Darf Steuerjahre nicht löschen
    canAddClient: true,
    canEditClient: true,
    canDeleteClient: false, // Darf Kunden nicht löschen
  },
  Client: {
    canNavigateBack: false, // Darf nicht zurück navigieren
    canEditProfile: true,
    canEditTaxYears: false, // Darf Steuerjahre nicht bearbeiten
    canDeleteTaxYears: false,
    canAddClient: false,
    canEditClient: false,
    canDeleteClient: false,
  },
};
