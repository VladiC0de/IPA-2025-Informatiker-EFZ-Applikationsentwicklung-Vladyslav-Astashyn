// Typ für einen Kunden
export interface Client {
  id?: number; // ID sollte immer existieren!
  salutation: string;
  lastName: string;
  firstName: string;
  email: string;
  phone: string;
  address: string;
  postalCode: number;
  city: string;
  taxYears: TaxYear[];
}
// Props für Kunde hinzufügen Formular
export interface AddClientFormProps {
  onClientAdded: (newClient: Client) => void;
  onClose: () => void;
}

// Typ für ein Steuerjahr
export interface TaxYear {
  year: number;
  stateTax: number;
  federalTax: number;
  totalTax: number;
  withholdingTaxPaid: number;
  difference: number;
  savings: number;
}

// Props für Suchleiste
export interface SearchBarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
}

//Rollen als array
export const ROLES = ["Admin", "Advisor", "Client"] as const;
//Typ aus ROLES array
export type Role = (typeof ROLES)[number];
// Rechte jeder rolle
export interface Permissions {
  canNavigateBack: boolean;
  canEditProfile: boolean;
  canEditTaxYears: boolean;
  canDeleteTaxYears: boolean;
  canAddClient: boolean;
  canEditClient: boolean;
  canDeleteClient: boolean;
}
//Props für Rollenwechsler
export interface RoleSwitcherProps {
  role: Role;
  setRole: (role: Role) => void;
}
// Props für die Startseite
export interface HomePageProps {
  role: Role;
  setRole: (role: Role) => void;
  onRowClick?: (id: number) => void;
}
//Props für Kundendetailsseite
export interface ClientDetailsPageProps {
  role: Role;
  setRole: (role: Role) => void;
  clientId?: number;
}
//Tabellen Props zum für die navigation
export interface TableProps {
  onRowClick: (id: string) => void;
}
// Typ zum Kunde bearbeiten
export type HandleEditCustomerField = (
  field: keyof Client,
  newValue: string | number
) => void;
// Props für Steuerjahr
export interface TaxYearsProps {
  taxYears: TaxYear[];
  role: Role;
  updateClient: (updatedTaxYears: TaxYear[]) => void;
}
//Typ zum Steuerjahr bearbeiten
export type HandleEditTaxYearField = (
  year: number,
  field: keyof TaxYear,
  newValue: number
) => void;
//Props zum Steuerjahr hinzufügen
export interface AddTaxYearFormProps {
  onTaxYearAdded: (newTaxYear: TaxYear) => void;
  onClose: () => void;
}
