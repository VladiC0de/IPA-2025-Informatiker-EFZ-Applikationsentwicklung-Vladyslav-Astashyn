import { Client } from "../types";

const STORAGE_KEY = "clientData";
// Kunde aus dem localStorage laden
export const loadClients = (): Client[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};
//Kunde im localStorage Speichern
export const saveClients = (clients: Client[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
};
//Kunde aus dem localStorage löschen
export const deleteClientFromStorage = (clientId: number): void => {
  const clients = loadClients();
  const updatedClients = clients.filter((client) => client.id !== clientId);
  saveClients(updatedClients);
};
//Die nächste ID finden
export const getNextClientId = (): number => {
  const idCounter = parseInt(localStorage.getItem("idCounter") || "1", 10);
  localStorage.setItem("idCounter", (idCounter + 1).toString());
  return idCounter;
};
// Kunde im localStorage Aktualissieren
export const updateClientInStorage = (updatedClient: Client): void => {
  const clients = loadClients();
  const index = clients.findIndex((client) => client.id === updatedClient.id);
  if (index !== -1) {
    clients[index] = updatedClient;
    saveClients(clients);
  }
};
