import HomePage from "./components/pages/HomePage";
import { useState } from "react";
import { Role } from "./types";
import { Routes, Route } from "react-router-dom";
import ClientDetailsPage from "./components/pages/ClientDetailsPage";
import "./styles/App.css";
const App = () => {
  const [role, setRole] = useState<Role>("Admin");

  return (
    <div className="app-container">
      <Routes>
        {/* Startseite*/}
        <Route path="/" element={<HomePage role={role} setRole={setRole} />} />

        {/* Detailseite*/}
        <Route
          path="/details/:id"
          element={<ClientDetailsPage role={role} setRole={setRole} />}
        />

        {/*falls die Seite nicht exestiert*/}
        <Route path="*" element={<h2>Page not found</h2>} />
      </Routes>
    </div>
  );
};
export default App;
