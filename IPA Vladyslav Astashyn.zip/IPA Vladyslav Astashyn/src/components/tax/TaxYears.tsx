import React, { useState } from "react";
import { TaxYear, TaxYearsProps, HandleEditTaxYearField } from "../../types";
import { ROLE_PERMISSIONS } from "../../roles/RolePermissions";
import AddTaxYearForm from "../forms/AddTaxYearForm";
import PencilIcon from "../../assets/Pencil.png";
import Checkmark from "../../assets/Checkmark.png";
import Trash from "../../assets/Trash.png";
import Cancel from "../../assets/Cancel.png";
import Modal from "../shared/Modal";

const TaxYears: React.FC<TaxYearsProps> = ({
  taxYears,
  role,
  updateClient,
}) => {
  const [updatedTaxYears, setUpdatedTaxYears] = useState<TaxYear[]>(taxYears);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [originalTaxYear, setOriginalTaxYear] = useState<TaxYear | null>(null);
  const [addingTaxYear, setAddingTaxYear] = useState(false);
  const [feedback, setFeedback] = useState<string>("");
  // Bearbeitungs Modus
  const handleEditClick = (index: number) => {
    setEditingIndex(index);
    setOriginalTaxYear({ ...updatedTaxYears[index] });
  };
  // Aktualisiert das Feld eines Steuerjahres
  const handleEditTaxYearField: HandleEditTaxYearField = (
    year,
    field,
    newValue
  ) => {
    setUpdatedTaxYears((prev) =>
      prev.map((taxYear, i) => {
        if (i !== year) return taxYear;

        const updatedTaxYear = { ...taxYear, [field]: newValue };

        if (field === "stateTax" || field === "federalTax") {
          updatedTaxYear.totalTax =
            updatedTaxYear.stateTax + updatedTaxYear.federalTax;
        }

        updatedTaxYear.difference =
          updatedTaxYear.totalTax - updatedTaxYear.withholdingTaxPaid;

        return updatedTaxYear;
      })
    );
  };
  //Steuerjahr Speichern
  const handleSave = () => {
    updateClient(updatedTaxYears);
    setEditingIndex(null);
    setFeedback("Changes saved successfully!");
    setTimeout(() => setFeedback(""), 2000);
  };
  //Bearbeitung abbrechen
  const handleCancel = () => {
    if (editingIndex !== null && originalTaxYear) {
      setUpdatedTaxYears((prev) => {
        const newList = [...prev];
        newList[editingIndex] = originalTaxYear;
        return newList;
      });
    }
    setEditingIndex(null);
    setOriginalTaxYear(null);
  };
  // Steuerjahr Löschen
  const handleDelete = (year: number) => {
    if (
      window.confirm(`Are you sure you want to delete the tax year ${year}?`)
    ) {
      setEditingIndex(null);
      const updatedList = updatedTaxYears.filter((ty) => ty.year !== year);
      setUpdatedTaxYears(updatedList);
      updateClient(updatedList);
      setFeedback(`Tax year ${year} deleted successfully!`);
      setTimeout(() => setFeedback(""), 2000);
    }
  };
  // Wert mit CHF anzeigen
  const formatValue = (value: string | number | undefined): string => {
    if (!value) return "CHF 0";
    const numericValue = typeof value === "string" ? parseFloat(value) : value;
    return `CHF ${numericValue.toLocaleString()}`;
  };
  // Zeichen in Number blockieren
  const blockInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (["e", "E", "+", "-", "."].includes(e.key)) {
      e.preventDefault();
    }
  };

  return (
    <div className="taxyears-container">
      <h1>Tax Years</h1>
      {ROLE_PERMISSIONS[role].canEditTaxYears && (
        <div className="add-taxyear-container">
          {!addingTaxYear ? (
            <button
              className="add-taxyear-button"
              onClick={() => setAddingTaxYear(true)}
            >
              Add Tax Year
            </button>
          ) : (
            <Modal onClose={() => setAddingTaxYear(false)}>
              <AddTaxYearForm
                onTaxYearAdded={(newTaxYear) => {
                  const updatedList = [...updatedTaxYears, newTaxYear];
                  setUpdatedTaxYears(updatedList);
                  updateClient(updatedList);
                }}
                onClose={() => setAddingTaxYear(false)}
              />
            </Modal>
          )}
          {feedback && (
            <div className="feedback-message with-spacing">{feedback}</div>
          )}
        </div>
      )}

      <div className="taxyears-table-container">
        <table className="taxyears-table">
          <thead>
            <tr>
              <th>Year</th>
              <th>State Tax</th>
              <th>Federal Tax</th>
              <th>Total Tax</th>
              <th>Withholding Tax Paid</th>
              <th>Difference</th>
              <th>Potential savings</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {updatedTaxYears.map((taxYear, index) => (
              <tr key={index}>
                {editingIndex === index ? (
                  <>
                    {/* Bearbeitungs Modus */}
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={taxYear.year}
                        onKeyDown={blockInput}
                        onChange={(e) =>
                          handleEditTaxYearField(
                            index,
                            "year",
                            Number(e.target.value)
                          )
                        }
                      />
                    </td>
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={taxYear.stateTax}
                        onKeyDown={blockInput}
                        onChange={(e) =>
                          handleEditTaxYearField(
                            index,
                            "stateTax",
                            Number(e.target.value)
                          )
                        }
                      />
                    </td>
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={taxYear.federalTax}
                        onKeyDown={blockInput}
                        onChange={(e) =>
                          handleEditTaxYearField(
                            index,
                            "federalTax",
                            Number(e.target.value)
                          )
                        }
                      />
                    </td>
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={taxYear.totalTax}
                        disabled
                      />
                    </td>
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={taxYear.withholdingTaxPaid}
                        onKeyDown={blockInput}
                        onChange={(e) =>
                          handleEditTaxYearField(
                            index,
                            "withholdingTaxPaid",
                            Number(e.target.value)
                          )
                        }
                      />
                    </td>
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={Math.abs(taxYear.difference)}
                        disabled
                        style={{
                          color:
                            taxYear.difference > 0
                              ? "red"
                              : taxYear.difference < 0
                                ? "green"
                                : "black",
                        }}
                      />
                    </td>
                    <td>
                      <input
                        className="form-input"
                        type="number"
                        value={taxYear.savings}
                        onKeyDown={blockInput}
                        onChange={(e) =>
                          handleEditTaxYearField(
                            index,
                            "savings",
                            Number(e.target.value)
                          )
                        }
                      />
                    </td>
                    <td className="actions-cell">
                      <div className="button-group-taxyears">
                        <button className="save-button" onClick={handleSave}>
                          <img
                            src={Checkmark}
                            alt="Checkmark"
                            className="checkmark-icon"
                          />
                        </button>
                        {ROLE_PERMISSIONS[role].canDeleteTaxYears && (
                          <button
                            className="delete-button"
                            onClick={() => handleDelete(taxYear.year)}
                          >
                            <img
                              src={Trash}
                              alt="Delete"
                              className="trash-icon"
                            />
                          </button>
                        )}
                        <button
                          className="cancel-button"
                          onClick={handleCancel}
                        >
                          <img
                            src={Cancel}
                            alt="Cancel"
                            className="cancel-icon"
                          />
                        </button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    {/* Anzeige-Modus */}
                    <td>{taxYear.year}</td>
                    <td>
                      <div className="td-content">
                        <span>{formatValue(taxYear.stateTax)}</span>
                        <button className="action-button">Tax return</button>
                      </div>
                    </td>
                    <td>
                      <div className="td-content">
                        <span>{formatValue(taxYear.federalTax)}</span>
                        <button className="action-button">
                          Provisional calculation
                        </button>
                      </div>
                    </td>
                    <td>
                      <div className="td-content">
                        <span>{formatValue(taxYear.totalTax)}</span>
                        <button className="action-button">Show comments</button>
                      </div>
                    </td>
                    <td>
                      <div className="td-content">
                        <span>{formatValue(taxYear.withholdingTaxPaid)}</span>
                      </div>
                    </td>
                    <td>
                      <div className="td-content">
                        <span
                          style={{
                            color:
                              taxYear.difference > 0
                                ? "red"
                                : taxYear.difference < 0
                                  ? "green"
                                  : "black",
                          }}
                        >
                          {formatValue(Math.abs(taxYear.difference))}
                        </span>
                        {taxYear.difference !== 0 && (
                          <div className="remaining-refund">
                            {taxYear.difference > 0 ? "remaining" : "refund"}
                          </div>
                        )}
                      </div>
                    </td>
                    <td>
                      <div className="td-content">
                        <span>{formatValue(taxYear.savings)}</span>
                        {taxYear.savings > 0 && (
                          <button className="action-button">
                            Show savings
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="actions-cell">
                      {ROLE_PERMISSIONS[role].canEditTaxYears && (
                        <button
                          className="edit-button"
                          onClick={() => handleEditClick(index)}
                        >
                          <img
                            src={PencilIcon}
                            alt="Edit"
                            className="pencil-icon"
                          />
                        </button>
                      )}
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TaxYears;
