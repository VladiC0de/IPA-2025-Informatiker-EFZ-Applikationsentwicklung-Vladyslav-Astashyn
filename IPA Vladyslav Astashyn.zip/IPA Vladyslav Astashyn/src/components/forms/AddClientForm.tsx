import React, { useState } from "react";
import { AddClientFormProps, Client } from "../../types";
import Cancel from "../../assets/cancel.png";
import Checkmark from "../../assets/checkmark.png";

const AddClientForm: React.FC<AddClientFormProps> = ({
  onClose,
  onClientAdded,
}) => {
  // Anfangszustand für Kunden
  const [client, setClient] = useState<Client>({
    salutation: "",
    lastName: "",
    firstName: "",
    email: "",
    phone: "",
    address: "",
    postalCode: 0,
    city: "",
    taxYears: [],
  });

  const [feedback, setFeedback] = useState<string>("");
  //Input Field änderung
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, type } = e.target;
    let { value } = e.target;

    if (name === "phone") {
      value = value.replace(/[^0-9+\s]/g, "");
    }

    if (name === "firstName" || name === "lastName") {
      value = value.replace(/[^A-Za-zÄÖÜäöü\s'-]/g, "");
    }

    if (name === "city") {
      value = value.replace(/[^A-Za-zÄÖÜäöüß\s'-]/g, "");
    }

    if (name === "address") {
      value = value.replace(/[^A-Za-z0-9ÄÖÜäöüß\s.,#/\-']/g, "");
    }

    setClient((prev) => ({
      ...prev,
      [name]: type === "number" ? (value ? Number(value) : 0) : value,
    }));
  };
  // Absenden des Formulars
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (
      !client.salutation ||
      !client.lastName ||
      !client.firstName ||
      !client.email ||
      !client.phone ||
      !client.address ||
      !client.postalCode ||
      !client.city
    ) {
      alert("Please fill in all fields.");
      return;
    }

    if (!validateEmail(client.email)) {
      alert("Please enter a valid email address.");
      return;
    }
    if (!validatePhone(client.phone)) {
      alert("Please enter a valid phone number.");
      return;
    }
    if (!validatePostalCode(client.postalCode)) {
      alert("Please enter a valid postal code.");
      return;
    }

    onClientAdded(client);
    setFeedback("Client added successfully!");
    setTimeout(() => {
      onClose();
    }, 2000);
  };
  // Validierungsfunktionen
  const validateEmail = (email: string): boolean => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    const regex = /^\+?[0-9\s-]+$/;
    return regex.test(phone);
  };

  const validatePostalCode = (postalCode: number): boolean => {
    return postalCode > 0 && postalCode.toString().length <= 10;
  };
  //bei Nummern fokgende zeichen blockieren
  const blockInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (["e", "E", "+", "-", "."].includes(e.key)) {
      e.preventDefault();
    }
  };

  return (
    <div className="add-client-container">
      <form className="add-client-form" onSubmit={handleSubmit}>
        <h2>Add New Client</h2>

        <select
          className="form-input"
          name="salutation"
          value={client.salutation}
          onChange={handleChange}
          required
        >
          <option value="" disabled hidden>
            Salutation
          </option>
          <option value="Mr.">Mr.</option>
          <option value="Mrs.">Mrs.</option>
        </select>
        <input
          className="form-input"
          type="text"
          name="lastName"
          placeholder="Last Name"
          value={client.lastName}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="text"
          name="firstName"
          placeholder="First Name"
          value={client.firstName}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="text"
          name="email"
          placeholder="Email"
          value={client.email}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="text"
          name="phone"
          placeholder="Phone"
          value={client.phone}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="text"
          name="address"
          placeholder="Address"
          value={client.address}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="number"
          name="postalCode"
          placeholder="Postal Code"
          value={client.postalCode || ""}
          onKeyDown={blockInput}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="text"
          name="city"
          placeholder="City"
          value={client.city}
          onChange={handleChange}
        />

        <div className="button-group">
          <button className="save-button" type="submit">
            <img src={Checkmark} alt="Checkmark" className="checkmark-icon" />
          </button>
          <button className="cancel-button" type="button" onClick={onClose}>
            <img src={Cancel} alt="Cancel" className="cancel-icon" />
          </button>
        </div>
        {feedback && <p className="feedback-message">{feedback}</p>}
      </form>
    </div>
  );
};


export default AddClientForm;
