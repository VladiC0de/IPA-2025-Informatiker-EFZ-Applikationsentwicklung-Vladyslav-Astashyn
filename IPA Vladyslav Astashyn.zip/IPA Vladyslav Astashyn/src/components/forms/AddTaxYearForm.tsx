import React, { useState } from "react";
import { TaxYear, AddTaxYearFormProps } from "../../types";
import Checkmark from "../../assets/Checkmark.png";
import Cancel from "../../assets/Cancel.png";

const AddTaxYearForm: React.FC<AddTaxYearFormProps> = ({
  onClose,
  onTaxYearAdded,
}) => {
  // Anfangszustand für Steuerjahr
  const [taxYear, setTaxYear] = useState<TaxYear>({
    year: 0,
    stateTax: 0,
    federalTax: 0,
    totalTax: 0,
    withholdingTaxPaid: 0,
    difference: 0,
    savings: 0,
  });

  const [feedback, setFeedback] = useState<string>("");

  //Input field änderungen
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    setTaxYear((prev) => ({
      ...prev,
      [name]: value ? Number(value) : 0,
    }));
  };
  //Formular absenden
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (
      !taxYear.year ||
      !taxYear.stateTax ||
      !taxYear.federalTax ||
      !taxYear.withholdingTaxPaid ||
      !taxYear.savings
    ) {
      alert("Please fill in all fields.");
      return;
    }

    if (taxYear.year < 2020 || taxYear.year > new Date().getFullYear() + 1) {
      alert("Please enter a valid year (between 2020 and next year).");
      return;
    }

    if (
      taxYear.stateTax < 0 ||
      taxYear.federalTax < 0 ||
      taxYear.withholdingTaxPaid < 0 ||
      taxYear.savings < 0
    ) {
      alert("All tax values must be positive numbers.");
      return;
    }

    const updatedTaxYear = {
      ...taxYear,
      totalTax: taxYear.stateTax + taxYear.federalTax,
      difference:
        taxYear.stateTax + taxYear.federalTax - taxYear.withholdingTaxPaid,
    };

    onTaxYearAdded(updatedTaxYear);
    setFeedback("Tax year added successfully!");
    setTimeout(() => {
      onClose();
      setFeedback("");
    }, 2000);
  };
  // bei zahlen folgende zeichen blockieren
  const blockInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (["e", "E", "+", "-", "."].includes(e.key)) {
      e.preventDefault();
    }
  };

  return (
    <div className="add-taxyear-container">
      <form className="add-taxyear-form" onSubmit={handleSubmit}>
        <h2>Add New Tax Year</h2>

        <input
          className="form-input"
          type="number"
          name="year"
          placeholder="Year"
          value={taxYear.year || ""}
          onKeyDown={blockInput}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="number"
          name="stateTax"
          placeholder="State Tax"
          value={taxYear.stateTax || ""}
          onKeyDown={blockInput}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="number"
          name="federalTax"
          placeholder="Federal Tax"
          value={taxYear.federalTax || ""}
          onKeyDown={blockInput}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="number"
          name="withholdingTaxPaid"
          placeholder="Withholding Tax Paid"
          value={taxYear.withholdingTaxPaid || ""}
          onKeyDown={blockInput}
          onChange={handleChange}
        />
        <input
          className="form-input"
          type="number"
          name="savings"
          placeholder="Potential savings"
          value={taxYear.savings || ""}
          onKeyDown={blockInput}
          onChange={handleChange}
        />

        <div className="button-group">
          <button className="save-button" type="submit">
            <img src={Checkmark} alt="Checkmark" className="checkmark-icon" />
          </button>
          <button className="cancel-button" type="button" onClick={onClose}>
            <img src={Cancel} alt="Cancel" className="cancel-icon" />
          </button>
        </div>

        {feedback && <p className="feedback-message">{feedback}</p>}
      </form>
    </div>
  );
};

export default AddTaxYearForm;
