import { describe, test, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import HomePage from "./HomePage";
import ClientDetailsPage from "./ClientDetailsPage";

describe("T-1 INT – Kunde hinzufügen", () => {
  test("Nach dem Ausfüllen des Formulars soll der Kunde hinzugefügt werden", async () => {
    const user = userEvent.setup();

    // HomePage in einem MemoryRouter rendern
    render(
      <MemoryRouter>
        <HomePage role="Admin" setRole={() => { }} />
      </MemoryRouter>
    );

    // Auf "Add Client" klicken, um das Formular anzuzeigen
    await user.click(screen.getByText("Add Client"));

    // Warte auf das Erscheinen der Überschrift im Formular
    const formHeading = await screen.findByText("Add New Client");
    const addClientForm = formHeading.closest("form");
    if (!addClientForm) throw new Error("Formular nicht gefunden");

    // Suche nach dem <select>-Element im Formular, das die Anrede steuert
    const salutationSelect = addClientForm.querySelector(
      "select[name='salutation']"
    ) as HTMLSelectElement;
    if (!salutationSelect) throw new Error("Salutation-Select nicht gefunden");

    // Wähle "Mr." aus dem Dropdown
    await user.selectOptions(salutationSelect, ["Mr."]);

    // Fülle die restlichen Felder aus
    await user.type(screen.getByPlaceholderText("Last Name"), "Muster");
    await user.type(screen.getByPlaceholderText("First Name"), "Max");
    await user.type(screen.getByPlaceholderText("Email"), "max@test.ch");
    await user.type(screen.getByPlaceholderText("Phone"), "+41791234567");
    await user.type(screen.getByPlaceholderText("Address"), "Teststrasse 123");
    await user.type(screen.getByPlaceholderText("Postal Code"), "8000");
    await user.type(screen.getByPlaceholderText("City"), "Zürich");

    // Klicke auf den Bestätigungs-Button (Checkmark-Button)
    await user.click(screen.getByRole("button", { name: /checkmark/i }));

    // Erwartung: Der Kunde "Muster" erscheint in der Liste
    expect(await screen.findByText("Muster")).toBeInTheDocument();
  });
});

describe("T-2 INT – Kunde löschen", () => {
  // Damit window.confirm im Test immer "OK" zurückgibt (true),
  // überschreiben wir es in beforeEach:
  beforeEach(() => {
    window.confirm = vi.fn().mockReturnValue(true);
  });

  test("Beim Klicken des Lösch-Buttons wird der Kunde entfernt", async () => {
    const user = userEvent.setup();

    // HomePage mit Admin-Rechten rendern (so ist der Lösch-Button sichtbar)
    render(
      <MemoryRouter>
        <HomePage role="Admin" setRole={() => { }} />
      </MemoryRouter>
    );

    screen.debug();

    // Da in deinen Mockdaten "Sophia Schneider" existiert, verwenden wir "Schneider" als Suchbegriff.
    const targetClientName = "Schneider";

    // Warte, bis der Kunde in der Tabelle erscheint
    const clientCell = await screen.findByText(targetClientName);
    expect(clientCell).toBeInTheDocument();

    // Suche die zugehörige Tabellenzeile
    const row = clientCell.closest("tr");
    if (!row) throw new Error("Tabellenzeile nicht gefunden");

    // Suche in der Zeile nach dem Lösch-Button (angenommen, er hat die CSS-Klasse "delete-button")
    const deleteButton = row.querySelector(".delete-button");
    if (!deleteButton) throw new Error("Lösch-Button nicht gefunden");

    // Klicke den Lösch-Button (das window.confirm wird automatisch mit true beantwortet)
    await user.click(deleteButton);

    // Überprüfe, dass der Kunde nun nicht mehr in der Liste erscheint
    expect(screen.queryByText(targetClientName)).not.toBeInTheDocument();
  });
});

describe("T-3 INT – Kundendaten bearbeiten", () => {
  test("Änderung der Kundendaten wird korrekt gespeichert und angezeigt", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // 1. Auf den Kunden "Sophia" warten und klicken
    const sophiaCell = await screen.findByText("Sophia");
    const row = sophiaCell.closest("tr");
    if (!row) throw new Error('Tabellenzeile für "Sophia" nicht gefunden');
    await user.click(row);

    // 2. Sicherstellen, dass wir auf der Detailseite sind
    await screen.findByText("Client Details");

    // 3. Den richtigen Bearbeiten-Button anhand des umliegenden Bereichs finden
    const allEditImages = await screen.findAllByAltText("Edit");

    const editImg = allEditImages.find((img) => {
      const wrapper = img.closest(".client-details");
      return !!wrapper;
    });

    if (!editImg) throw new Error("Passendes Edit-Icon im Kundenbereich nicht gefunden");
    const editButton = editImg.closest("button");
    if (!editButton) throw new Error("Bearbeiten-Button nicht gefunden");
    await user.click(editButton);

    // 4. Vorname ändern
    const inputs = screen.getAllByDisplayValue("Sophia");
    const firstNameInput = inputs.find((input) =>
      input
        .closest(".field-display")
        ?.querySelector(".field-label")
        ?.textContent?.includes("First Name")
    );
    if (!firstNameInput) throw new Error('Input-Feld für "First Name" nicht gefunden');
    await user.clear(firstNameInput);
    await user.type(firstNameInput, "Sophie");

    // 5. Speichern (Checkmark-Icon)
    const checkmarkImg = await screen.findByAltText("Checkmark");
    const saveButton = checkmarkImg.closest("button");
    if (!saveButton) throw new Error("Speichern-Button nicht gefunden");
    await user.click(saveButton);

    // 6. Bestätigen, dass Änderung sichtbar ist
    const updatedName = await screen.findByText("Sophie");
    expect(updatedName).toBeInTheDocument();
  });
});

describe("T-4 INT – Steuerjahr löschen", () => {
  test("Ein Steuerjahr wird korrekt aus der Liste entfernt", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // 1. Kunde "Sophia" finden und klicken
    const sophiaCell = await screen.findByText("Sophia");
    const row = sophiaCell.closest("tr");
    if (!row) throw new Error("Tabellenzeile für Sophia nicht gefunden");
    await user.click(row);

    // 2. Sicherstellen, dass wir auf der Detailseite sind
    await screen.findByText("Client Details");

    // 3. Sicherstellen, dass das Jahr 2022 als Text sichtbar ist (noch kein Input!)
    await screen.findByText("2022");

    // 4. Jetzt in den Bearbeitungsmodus wechseln → 2. "Edit"-Button verwenden
    const editImgs = await screen.findAllByAltText("Edit");
    if (editImgs.length < 2) throw new Error("Nicht genügend Edit-Icons gefunden");
    const editButton = editImgs[1].closest("button");
    if (!editButton) throw new Error("Bearbeiten-Button nicht gefunden");
    await user.click(editButton);

    // 5. Jetzt sollte das Jahr 2022 als <input> erscheinen
    const yearInput = await screen.findByDisplayValue("2022");
    const taxRow = yearInput.closest("tr");
    if (!taxRow) throw new Error("Tabellenzeile für Steuerjahr nicht gefunden");

    // 6. Delete-Button finden und bestätigen
    const deleteButton = taxRow.querySelector(".delete-button");
    if (!deleteButton) throw new Error("Lösch-Button für Steuerjahr nicht gefunden");
    window.confirm = vi.fn().mockReturnValue(true);
    await user.click(deleteButton);

    // 7. Sicherstellen, dass das Jahr 2022 verschwunden ist
    expect(screen.queryByDisplayValue("2022")).not.toBeInTheDocument();
  });
});

describe("T-5 INT – Steuerjahr bearbeiten", () => {
  test("Geänderte Steuerjahr-Daten werden korrekt gespeichert und angezeigt", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // 1. Kunde "Sophia" finden und klicken
    const sophiaCell = await screen.findByText("Sophia");
    const row = sophiaCell.closest("tr");
    if (!row) throw new Error("Tabellenzeile für Sophia nicht gefunden");
    await user.click(row);

    // 2. Sicherstellen, dass wir auf der Detailseite sind
    await screen.findByText("Client Details");

    // 3. Text "2022" finden (als static Text, nicht input!)
    const yearCell = await screen.findByText("2022");
    const taxRow = yearCell.closest("tr");
    if (!taxRow) throw new Error("Zeile für Steuerjahr 2022 nicht gefunden");

    // 4. Edit-Button in der Steuerjahr-Zeile klicken
    const editButton = taxRow.querySelector(".edit-button");
    if (!editButton) throw new Error("Edit-Button für Steuerjahr 2022 nicht gefunden");
    await user.click(editButton);

    // 5. Jetzt: Input-Feld für State Tax holen (zweites Input-Feld in dieser Zeile)
    const inputs = taxRow.querySelectorAll("input");
    const stateTaxInput = inputs[1]; // Index 1 = State Tax
    if (!stateTaxInput) throw new Error("State Tax Input nicht gefunden");

    // 6. Wert ändern auf "3500"
    await user.clear(stateTaxInput);
    await user.type(stateTaxInput, "3500");

    // 7. Speichern (Checkmark Button)
    const saveButton = taxRow.querySelector(".save-button");
    if (!saveButton) throw new Error("Save-Button (Checkmark) nicht gefunden");
    await user.click(saveButton);

    // 8. Sicherstellen, dass der neue Wert korrekt angezeigt wird
    expect(await screen.findByText("CHF 3.500")).toBeInTheDocument();
  });
});

describe("T-6 INT – Steuerjahr hinzufügen", () => {
  test("Nach dem Ausfüllen des Formulars wird das Steuerjahr korrekt hinzugefügt", async () => {
    const user = userEvent.setup();

    // App über die Startseite rendern
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // 1. Auf die Kundin „Sophia“ klicken
    const sophiaCell = await screen.findByText("Sophia");
    const row = sophiaCell.closest("tr");
    if (!row) throw new Error("Tabellenzeile für Sophia nicht gefunden");
    await user.click(row);

    // 2. Sicherstellen, dass Detailseite geladen ist
    await screen.findByText("Client Details");

    // 3. Auf „Steuerjahr hinzufügen“ klicken
    const addButton = await screen.findByRole("button", { name: /add tax year/i });
    await user.click(addButton);

    // 4. Felder ausfüllen
    await user.type(screen.getByPlaceholderText("Year"), "2024");
    await user.type(screen.getByPlaceholderText("State Tax"), "3500");
    await user.type(screen.getByPlaceholderText("Federal Tax"), "18000");
    await user.type(screen.getByPlaceholderText("Withholding Tax Paid"), "20000");
    await user.type(screen.getByPlaceholderText("Potential savings"), "400");

    // 5. Speichern klicken
    const saveButton = await screen.findByRole("button", { name: /checkmark/i });
    await user.click(saveButton);

    // 6. Sicherstellen, dass das neue Jahr sichtbar ist
    expect(await screen.findByText("2024")).toBeInTheDocument();
  });
});

describe("T-7 INT – Kunde hinzufügen und in Details aufrufen", () => {
  test("Ein neuer Kunde wird korrekt zur Detailseite weitergeleitet", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // Auf "Add Client" klicken, um das Formular anzuzeigen
    await user.click(screen.getByText("Add Client"));

    // Warte auf das Erscheinen der Überschrift im Formular
    const formHeading = await screen.findByText("Add New Client");
    const addClientForm = formHeading.closest("form");
    if (!addClientForm) throw new Error("Formular nicht gefunden");

    // Suche nach dem <select>-Element im Formular, das die Anrede steuert
    const salutationSelect = addClientForm.querySelector(
      "select[name='salutation']"
    ) as HTMLSelectElement;
    if (!salutationSelect) throw new Error("Salutation-Select nicht gefunden");

    // Wähle "Mr." aus dem Dropdown
    await user.selectOptions(salutationSelect, ["Mr."]);
    await user.type(screen.getByPlaceholderText("Last Name"), "Testmann");
    await user.type(screen.getByPlaceholderText("First Name"), "Testo");
    await user.type(screen.getByPlaceholderText("Email"), "testo@example.com");
    await user.type(screen.getByPlaceholderText("Phone"), "+41791234567");
    await user.type(screen.getByPlaceholderText("Address"), "Testgasse 1");
    await user.type(screen.getByPlaceholderText("Postal Code"), "8000");
    await user.type(screen.getByPlaceholderText("City"), "Zürich");

    await user.click(screen.getByRole("button", { name: /checkmark/i }));

    // In der Tabelle auf den Kunden klicken
    const tableRow = await screen.findByText("Testmann");
    await user.click(tableRow);

    // Prüfen, ob wir auf der Detailseite gelandet sind und der Name sichtbar ist
    expect(await screen.findByText("Testo")).toBeInTheDocument();
  });
});

describe("T-8 INT – Kunde bearbeiten und Suchfunktion nutzen", () => {
  test("Ein Kunde wird bearbeitet und über die Suchleiste gefunden", async () => {
    const user = userEvent.setup();

    // 1. App mit Startseite (HomePage) rendern
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // 2. Warten, bis Sophia erscheint, dann zur Detailseite klicken
    const sophiaCell = await screen.findByText("Sophia");
    const row = sophiaCell.closest("tr");
    if (!row) throw new Error('Tabellenzeile für "Sophia" nicht gefunden');
    await user.click(row);

    // 3. Auf der Detailseite: "Sophia" wird angezeigt
    await screen.findByText("Sophia");

    // 4. Bearbeiten-Button für Kundendaten finden (erster "Edit"-Button)
    const editImgs = await screen.findAllByAltText("Edit");
    if (editImgs.length < 1) throw new Error("Kein Edit-Icon gefunden");
    const editButton = editImgs[0].closest("button");
    if (!editButton) throw new Error("Bearbeiten-Button nicht gefunden");
    await user.click(editButton);

    // 5. Input für "First Name" finden über Label-Kontext
    const inputs = screen.getAllByDisplayValue("Sophia");
    const firstNameInput = inputs.find((input) =>
      input
        .closest(".field-display")
        ?.querySelector(".field-label")
        ?.textContent?.includes("First Name")
    );
    if (!firstNameInput)
      throw new Error('Input-Feld für "First Name" nicht gefunden');

    await user.clear(firstNameInput);
    await user.type(firstNameInput, "SofieSuchtest");

    // 6. Speichern (über alt="Checkmark" → Button klicken)
    const checkmarkImg = await screen.findByAltText("Checkmark");
    const saveButton = checkmarkImg.closest("button");
    if (!saveButton) throw new Error("Speichern-Button nicht gefunden");
    await user.click(saveButton);

    // 7. Sicherstellen, dass neuer Wert übernommen wurde
    await screen.findByText("SofieSuchtest");

    // 8. Zurück zur Startseite & Suche
    const backButton = await screen.findByRole("button", { name: /back/i });
    await user.click(backButton);

    const searchInput = await screen.findByPlaceholderText(/search/i);
    await user.type(searchInput, "SofieSuchtest");

    // 9. Kunde mit geändertem Namen erscheint
    expect(await screen.findByText("SofieSuchtest")).toBeInTheDocument();
  });
});

describe("T-9 INT – Rolle beeinflusst Benutzeroberfläche und Rechte", () => {
  test("Der Löschbutton wird je nach Rolle korrekt angezeigt oder versteckt", async () => {

    // 1. Als Admin starten → Löschbutton sollte sichtbar sein
    const { rerender } = render(
      <MemoryRouter>
        <HomePage role="Admin" setRole={() => { }} />
      </MemoryRouter>
    );

    // 2. Auf "Schneider" warten → Zeile finden
    const clientCell = await screen.findByText("Schneider");
    const row = clientCell.closest("tr");
    if (!row) throw new Error("Kundenzeile nicht gefunden");

    // 3. Button mit Klasse .delete-button prüfen
    const deleteButton = row.querySelector(".delete-button");
    expect(deleteButton).toBeInTheDocument();

    // 4. Als Advisor neu rendern → Rolle ohne Löschrecht
    rerender(
      <MemoryRouter>
        <HomePage role="Advisor" setRole={() => { }} />
      </MemoryRouter>
    );

    // 5. Prüfen, ob Löschbutton nun nicht mehr vorhanden ist
    expect(screen.queryByText("Schneider")).toBeInTheDocument();
    const updatedRow = screen.getByText("Schneider").closest("tr");
    const advisorDeleteBtn = updatedRow?.querySelector(".delete-button");
    expect(advisorDeleteBtn).not.toBeInTheDocument();
  });
});



describe("T-10 INT – Kunde hinzufügen und Steuerjahr hinzufügen", () => {
  test("Ein Kunde wird hinzugefügt und danach ein Steuerjahr", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route
            path="/"
            element={<HomePage role="Admin" setRole={() => { }} />}
          />
          <Route
            path="/details/:id"
            element={<ClientDetailsPage role="Admin" setRole={() => { }} />}
          />
        </Routes>
      </MemoryRouter>
    );

    // 1. Auf "Add Client" klicken
    await user.click(screen.getByText("Add Client"));

    // 2. Formular anzeigen und Salutation-Select finden
    const formHeading = await screen.findByText("Add New Client");
    const addClientForm = formHeading.closest("form");
    if (!addClientForm) throw new Error("Formular nicht gefunden");

    const salutationSelect = addClientForm.querySelector(
      "select[name='salutation']"
    ) as HTMLSelectElement;
    if (!salutationSelect) throw new Error("Salutation-Select nicht gefunden");

    // 3. Formular ausfüllen
    await user.selectOptions(salutationSelect, ["Mr."]);
    await user.type(screen.getByPlaceholderText("Last Name"), "Steuerlich");
    await user.type(screen.getByPlaceholderText("First Name"), "Klaus");
    await user.type(screen.getByPlaceholderText("Email"), "klaus@steuer.ch");
    await user.type(screen.getByPlaceholderText("Phone"), "0777777777");
    await user.type(screen.getByPlaceholderText("Address"), "Teststrasse");
    await user.type(screen.getByPlaceholderText("Postal Code"), "9999");
    await user.type(screen.getByPlaceholderText("City"), "Zug");

    // 4. Formular abschicken
    await user.click(screen.getByRole("button", { name: /checkmark/i }));

    // 5. Kunde in der Tabelle klicken
    const tableRow = await screen.findByText("Steuerlich");
    await user.click(tableRow);

    // 6. "Add Tax Year"-Button klicken
    await user.click(await screen.findByRole("button", { name: /add tax year/i }));

    // 7. Steuerjahr-Formular ausfüllen
    await user.type(screen.getByPlaceholderText("Year"), "2025");
    await user.type(screen.getByPlaceholderText("State Tax"), "4000");
    await user.type(screen.getByPlaceholderText("Federal Tax"), "12000");
    await user.type(screen.getByPlaceholderText("Withholding Tax Paid"), "15000");
    await user.type(screen.getByPlaceholderText("Potential savings"), "300");

    // 8. Speichern
    await user.click(screen.getByRole("button", { name: /checkmark/i }));

    // 9. Steuerjahr erscheint
    expect(await screen.findByText("2025")).toBeInTheDocument();
  });
});

describe("T-11 INT – Steuerjahr bearbeiten und korrekt auf Startseite anzeigen", () => {
  test("Bearbeitetes Steuerjahr wird korrekt auf der Startseite angezeigt", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route path="/" element={<HomePage role="Admin" setRole={() => {}} />} />
          <Route path="/details/:id" element={<ClientDetailsPage role="Admin" setRole={() => {}} />} />
        </Routes>
      </MemoryRouter>
    );

    // 1. Zur Detailseite des Kunden „Sophia“ navigieren
    const sophiaCell = await screen.findByText("Sophia");
    const row = sophiaCell.closest("tr");
    if (!row) throw new Error("Tabellenzeile für Sophia nicht gefunden");
    await user.click(row);

    // 2. Steuerjahr "2022" finden
    const yearCell = await screen.findByText("2022");
    const taxRow = yearCell.closest("tr");
    if (!taxRow) throw new Error("Zeile für Steuerjahr 2022 nicht gefunden");

    // 3. Edit-Button in der Steuerjahr-Zeile klicken
    const editButton = taxRow.querySelector(".edit-button");
    if (!editButton) throw new Error("Edit-Button für Steuerjahr nicht gefunden");
    await user.click(editButton);

    // 4. Jahr ändern auf "2026"
    const inputs = taxRow.querySelectorAll("input");
    const yearInput = inputs[0]; // erstes Feld = Jahr
    if (!yearInput) throw new Error("Year-Input nicht gefunden");
    await user.clear(yearInput);
    await user.type(yearInput, "2026");

    // 5. Speichern klicken
    const saveButton = taxRow.querySelector(".save-button");
    if (!saveButton) throw new Error("Speichern-Button nicht gefunden");
    await user.click(saveButton);

    // 6. Zurück zur Startseite navigieren
    const backButton = await screen.findByRole("button", { name: /back/i });
    await user.click(backButton);

    // 7. Prüfen, ob das geänderte Jahr "2026" in Sophias Zeile steht
    const updatedRow = await screen.findByText("Sophia").then((cell) => cell.closest("tr"));
    if (!updatedRow) throw new Error("Sophia-Zeile auf der Startseite nicht gefunden");

    expect(updatedRow.textContent).toContain("2026");
  });
});

describe("T-12 INT – Kunde löschen und erneuten Zugriff prüfen", () => {
  test.only("Gelöschter Kunde ist über Direktlink nicht mehr aufrufbar", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route path="/" element={<HomePage role="Admin" setRole={() => { }} />} />
          <Route path="/details/:id" element={<ClientDetailsPage role="Admin" setRole={() => { }} />} />
        </Routes>
      </MemoryRouter>
    );

    // 1. Kunde "Schneider" finden
    const schneiderCell = await screen.findByText("Schneider");
    const row = schneiderCell.closest("tr");
    if (!row) throw new Error("Kundenzeile nicht gefunden");

    // 2. ID extrahieren aus erster Zelle
    const id = row.querySelector("td")?.textContent;
    if (!id) throw new Error("ID nicht gefunden");

    // 3. Direktlink generieren
    const directLink = `/details/${id}`;

    // 4. Löschen bestätigen
    const deleteBtn = row.querySelector(".delete-button");
    if (!deleteBtn) throw new Error("Lösch-Button nicht gefunden");
    window.confirm = vi.fn().mockReturnValue(true);
    await user.click(deleteBtn);

    // 5. Versuche erneut die Detailseite aufzurufen
    render(
      <MemoryRouter initialEntries={[directLink]}>
        <Routes>
          <Route path="/details/:id" element={<ClientDetailsPage role="Admin" setRole={() => { }} />} />
        </Routes>
      </MemoryRouter>
    );

    // 6. Prüfen, ob nichts mehr sichtbar ist
    expect(screen.queryByText("Client Details")).not.toBeInTheDocument();
    expect(screen.queryByDisplayValue("Schneider")).not.toBeInTheDocument();
  });
});
               