import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Client,
  ClientDetailsPageProps,
  HandleEditCustomerField,
  TaxYear,
} from "../../types";
import {
  loadClients,
  updateClientInStorage,
  deleteClientFromStorage,
} from "../../services/StorageService";
import RoleSwitcher from "../shared/RoleSwitcher";
import { ROLE_PERMISSIONS } from "../../roles/RolePermissions";
import TaxYears from "../tax/TaxYears";
import "../../styles/ClientDetailsPage.css";
import Logo from "../../assets/ajooda.png";
import Pencil from "../../assets/pencil.png";
import Trash from "../../assets/trash.png";
import Cancel from "../../assets/cancel.png";
import Checkmark from "../../assets/checkmark.png";
import Expand from "../../assets/expand.png";
import Collapse from "../../assets/collapse.png";

const ClientDetailsPage: React.FC<ClientDetailsPageProps> = ({
  role,
  setRole,
}) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const clients = loadClients();
  const clientIndex = clients.findIndex((c) => c.id === Number(id));
  const [isEditing, setIsEditing] = useState(false);
  const [client, setClient] = useState<Client>(
    clientIndex !== -1 ? clients[clientIndex] : ({} as Client)
  );
  const [originalClient, setOriginalClient] = useState<Client>(client);
  const [deleted, setDeleted] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string>("");
  const [collapsed, setCollapsed] = useState<boolean>(false);

  if (clientIndex === -1 && !deleted) {
    return (
      <div>
        <h2>Client not found.</h2>
        <button onClick={() => navigate("/")}>Back to Home</button>
      </div>
    );
  }

  if (deleted) {
    return <div>{feedback && <p>{feedback}</p>}</div>;
  }
  // Felder anzeigen
  const renderField = (
    label: string,
    value: string | number,
    field: keyof Client
  ) => {
    return (
      <div className="field-display">
        <span className="field-label">{label}:</span>
        {isEditing ? (
          <input
            className="form-input"
            type="text"
            value={value}
            onChange={(e) => {
              const newVal =
                typeof value === "number"
                  ? Number(e.target.value)
                  : e.target.value;
              handleEditCustomerField(field, newVal.toString());
            }}
          />
        ) : (
          <span className="field-value">{value}</span>
        )}
      </div>
    );
  };
  // Aktualisiert Kundenfeld
  const handleEditCustomerField: HandleEditCustomerField = (
    field,
    newValue
  ) => {
    setClient((prev) => ({
      ...prev,
      [field]: typeof prev[field] === "number" ? Number(newValue) : newValue,
    }));
  };
  //Kunde Speichern
  const handleSave = () => {
    updateClientInStorage(client);
    setClient({ ...client });
    setIsEditing(false);
    setFeedback("Changes saved successfully!");
    setTimeout(() => setFeedback(""), 2000);
  };
  // Abbrechen des Bearbeitungsmodus
  const handleCancelEdit = () => {
    setClient(originalClient);
    setIsEditing(false);
  };
  // Kunde löschen
  const handleDelete = () => {
    if (role !== "Admin") {
      alert("You do not have permission to delete clients.");
      return;
    }
    if (window.confirm("Are you sure you want to delete this client?")) {
      deleteClientFromStorage(client.id!);
      setFeedback("Client deleted successfully!");
      setDeleted(true);
      setTimeout(() => {
        navigate("/");
      }, 2000);
    }
  };
  // Kunde Aktualisieren
  const updateClient = (updatedTaxYears: TaxYear[]) => {
    const updatedClient = { ...client, taxYears: updatedTaxYears };
    setClient(updatedClient);
    updateClientInStorage(updatedClient);
  };
  // Auf und Zuklappen
  const toggleCollapse = () => {
    setCollapsed((prev) => !prev);
  };

  return (
    <div className="client-container">
      <div className="top-container">
        <div className="logo-container">
          <img src={Logo} alt="Ajooda Logo" className="logo" />
          {ROLE_PERMISSIONS[role].canNavigateBack && (
            <button className="back-button" onClick={() => navigate("/")}>
              Back
            </button>
          )}
        </div>
        <RoleSwitcher role={role} setRole={setRole} />
      </div>
      <div className="client-taxyears">
        <div
          className={`client-details-wrapper ${collapsed ? "collapsed" : ""}`}
        >
          {!collapsed && (
            <div className="client-details">
              <div className="client-header">
                <h1>Client Details</h1>
                <button className="toggle-button" onClick={toggleCollapse}>
                  <img
                    src={Collapse}
                    alt="Collapse"
                    className="collapse-icon"
                  />
                </button>
              </div>
              {renderField("Salutation", client.salutation || "", "salutation")}
              {renderField("Last Name", client.lastName, "lastName")}
              {renderField("First Name", client.firstName, "firstName")}
              {renderField("Email", client.email, "email")}
              {renderField("Phone Number", client.phone, "phone")}
              {renderField("Address", client.address, "address")}
              {renderField(
                "Postal Code",
                client.postalCode || "",
                "postalCode"
              )}
              {renderField("City", client.city || "", "city")}

              {(ROLE_PERMISSIONS[role].canEditProfile ||
                ROLE_PERMISSIONS[role].canDeleteClient) && (
                  <div className="button-group">
                    {ROLE_PERMISSIONS[role].canEditProfile &&
                      (isEditing ? (
                        <>
                          <button className="save-button" onClick={handleSave}>
                            <img
                              src={Checkmark}
                              alt="Checkmark"
                              className="checkmark-icon"
                            />
                          </button>
                          <button
                            className="cancel-button"
                            onClick={handleCancelEdit}
                          >
                            <img
                              src={Cancel}
                              alt="Cancel"
                              className="cancel-icon"
                            />
                          </button>
                        </>
                      ) : (
                        <button
                          className="edit-button"
                          onClick={() => {
                            setOriginalClient(client);
                            setIsEditing(true);
                          }}
                        >
                          <img src={Pencil} alt="Edit" className="pencil-icon" />
                        </button>
                      ))}
                    {ROLE_PERMISSIONS[role].canDeleteClient && (
                      <button className="delete-button" onClick={handleDelete}>
                        <img src={Trash} alt="Delete" className="trash-icon" />
                      </button>
                    )}
                  </div>
                )}
              {feedback && <div className="feedback-message">{feedback}</div>}
            </div>
          )}
        </div>
        {collapsed && (
          <div className="button-column">
            <button className="toggle-button" onClick={toggleCollapse}>
              <img src={Expand} alt="Expand" className="expand-icon" />
            </button>
          </div>
        )}
        <div className="tax-years">
          <TaxYears
            taxYears={client.taxYears}
            role={role}
            updateClient={updateClient}
          />
        </div>
      </div>
    </div>
  );
};

export default ClientDetailsPage;
