import React, { useEffect, useState } from "react";
import { Client, HomePageProps } from "../../types";
import clientData from "../../MockData";
import AddClientForm from "../forms/AddClientForm";
import {
  deleteClientFromStorage,
  loadClients,
  saveClients,
  getNextClientId,
} from "../../services/StorageService";
import SearchBar from "../search/SearchBar";
import { ROLE_PERMISSIONS } from "../../roles/RolePermissions";
import RoleSwitcher from "../shared/RoleSwitcher";
import { useNavigate } from "react-router-dom";
import "../../styles/HomePage.css";
import logo from "../../assets/ajooda.png";
import Trash from "../../assets/trash.png";
import Modal from "../shared/Modal";

const HomePage: React.FC<HomePageProps> = ({ role, setRole }) => {
  const [clients, setClients] = useState<Client[]>(clientData);

  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  const [searchTerm, setSearchTerm] = useState<string>("");

  const navigate = useNavigate();

  const [feedback, setFeedback] = useState<string>("");
  //Ladet die Mockdaten oder die Daten im localStorage
  useEffect(() => {
    try {
      const parsedData = loadClients();
      if (parsedData.length > 0) {
        setClients(parsedData);

        const storedCounter = localStorage.getItem("idCounter");
        if (!storedCounter) {
          const highestId =
            parsedData.length > 0
              ? Math.max(...parsedData.map((c) => c.id || 0))
              : 0;
          localStorage.setItem("idCounter", (highestId + 1).toString());
        }
      } else {
        setClients(clientData);
        saveClients(clientData);
        localStorage.setItem("idCounter", (clientData.length + 1).toString());
      }
    } catch (error) {
      console.error("Failed to load clients:", error);
      alert("Failed to load client data. Please try again later.");
    }
  }, []);
  // Falls Rolle Client ist wird man auf die Kundendetailsseite mit der ersten ID weitergeleitet
  useEffect(() => {
    if (role === "Client" && clients.length > 0) {
      navigate(`/details/${clients[0].id}`);
    }
  }, [role, clients, navigate]);
  //Kunde hinzufügen
  const handleClientAdded = (newClient: Client) => {
    const savedData = loadClients();
    const clientWithId = { ...newClient, id: getNextClientId() };
    const updatedClients = [...savedData, clientWithId];
    setClients(updatedClients);
    saveClients(updatedClients);
  };
  //Kunde Löschen
  const handleClientDeleted = (id: number) => {
    if (role !== "Admin") {
      alert("You do not have permission to delete clients.");
      return;
    }
    if (window.confirm("Are you sure you want to delete this client?")) {
      deleteClientFromStorage(id);
      const updatedClients = clients.filter((client) => client.id !== id);
      setClients(updatedClients);
      setFeedback("Client deleted successfully!");
      setTimeout(() => setFeedback(""), 2000);
    }
  };
  //Filterfunktion
  const filteredClients = clients.filter((client) =>
    `${client.firstName} ${client.lastName} ${client.email}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );
  //Navigation zur Kundendetailsseite
  const RowClick = (id: number | undefined) => {
    if (id !== undefined) {
      navigate(`/details/${id}`);
    }
  };

  return (
    <div className="homepage-container">
      <div className="top-container">
        <img src={logo} alt="Ajooda Logo" className="logo" />
        <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
        <RoleSwitcher role={role} setRole={setRole} />
      </div>
      <div className="client-container">
        <h1>Client List</h1>
        {ROLE_PERMISSIONS[role].canAddClient && (
          <button
            className="add-client-button"
            onClick={() => setShowAddForm(true)}
          >
            Add Client
          </button>
        )}
        {feedback && (
          <div className="feedback-message with-spacing">{feedback}</div>
        )}
        {showAddForm && (
          <Modal onClose={() => setShowAddForm(false)}>
            <AddClientForm
              onClose={() => setShowAddForm(false)}
              onClientAdded={(newClient) => {
                handleClientAdded(newClient);
              }}
            />
          </Modal>
        )}
        {/* Kunden-Tabelle */}
        <table className="client-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Last Name</th>
              <th>First Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Tax Years</th>
              <th>Actions</th>{" "}
            </tr>
          </thead>
          <tbody>
            {filteredClients.length > 0 ? (
              filteredClients.map((client) => (
                <tr
                  key={client.id}
                  onClick={(e) => {
                    if ((e.target as HTMLElement).tagName === "BUTTON") return;
                    RowClick(client.id);
                  }}
                  className="table-row"
                >
                  <td className="table-cell">{client.id}</td>
                  <td className="table-cell">{client.lastName}</td>
                  <td className="table-cell">{client.firstName}</td>
                  <td className="table-cell">{client.email}</td>
                  <td className="table-cell">{client.phone}</td>
                  <td className="table-cell">{client.address}</td>
                  <td className="table-cell">
                    {(client.taxYears || []).map((t) => t.year).join(", ")}
                  </td>
                  <td className="table-cell">
                    {ROLE_PERMISSIONS[role].canDeleteClient ? (
                      <button
                        className="delete-button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleClientDeleted(client.id!);
                        }}
                      >
                        <img src={Trash} alt="Delete" className="trash-icon" />
                      </button>
                    ) : (
                      ""
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="no-clients-cell">
                  No Clients found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HomePage;
