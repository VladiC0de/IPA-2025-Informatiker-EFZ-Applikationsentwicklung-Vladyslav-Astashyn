import React from "react";
import { ROLES, Role, RoleSwitcherProps } from "../../types";


// Rollenwechsler Komponente
const RoleSwitcher: React.FC<RoleSwitcherProps> = ({ role, setRole }) => {
  return (
    <div className="role-switcher-container">
      <label htmlFor="role-switcher">Switch Role:</label>
      <select
        id="role-switcher"
        value={role}
        onChange={(event) => setRole(event.target.value as Role)}
      >
        {ROLES.map(
          (
            roleOption 
          ) => (
            <option key={roleOption} value={roleOption}>
              {roleOption}
            </option>
          )
        )}
      </select>
    </div>
  );
};

export default RoleSwitcher;
