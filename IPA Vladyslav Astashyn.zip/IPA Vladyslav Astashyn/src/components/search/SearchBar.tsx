import React from "react";
import { SearchBarProps } from "../../types";
import Cancel from "../../assets/CancelBlack.png";

const SearchBar: React.FC<SearchBarProps> = ({ searchTerm, setSearchTerm }) => {
  //Suche löschen
  const ClearSearch = () => {
    setSearchTerm("");
  };

  return (
    <div className="search-bar-container">
      <input
        type="text"
        className="search-bar-input"
        placeholder="Search clients..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {searchTerm && (
        <button
          type="button"
          onClick={ClearSearch}
          className="clear-button"
        >
          <img src={Cancel} alt="Clear" className="clear-icon" />
        </button>
      )}
    </div>
  );
};

export default SearchBar;
